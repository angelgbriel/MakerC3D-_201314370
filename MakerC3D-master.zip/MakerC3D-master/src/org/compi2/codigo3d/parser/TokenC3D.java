package org.compi2.codigo3d.parser;

/**
 *
 * @author esvux
 */
public class TokenC3D {
    
}
